//
//  Admin.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI

struct AdminView: View {
    @State var AddProduct: Bool = false
    @State var UserOrder: Bool = false
    @Environment(\.presentationMode) var presentationMode
    @State var color = Color("Color")
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return
            HStack{
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(color)
                Spacer()
            }
    }
    var body: some View {
        ZStack{
            VStack{
                Grid{
                    GridRow{
                    color
                    .overlay {
                        Button {
                        AddProduct = true
                        } label: {
                        Image(systemName: "fork.knife")
                            .font(.system(size: 100))
                            .foregroundColor(Color("bg"))
                                }
                            }
                        color
                        .overlay {
                            Button {
                            UserOrder = true
                            } label: {
                            Image(systemName: "list.bullet.clipboard.fill")
                                .font(.system(size: 100))
                                .foregroundColor(Color("bg"))
                                    }
                                }
                        Color(.blue)
                        
                    }
                }
                Grid{
                    GridRow{
                        Color(.black)
                        Color(.white)
                       
                        Color(.green)
                        
                    }
                }
                Grid{
                    GridRow{
                        Color(.brown)
                        Color(.purple)
                        Color(.gray)
                        
                    }
                }
                Grid{
                    GridRow{
                        Color(.red)
                        Color(.yellow)
                        Color(.blue)
                        
                    }
                }
            }
        }.sheet(isPresented: $AddProduct) {
            Mujtahid.AddProduct()
        }
        .sheet(isPresented: $UserOrder) {
           // Mujtahid.AllUser()
        }
    }
}

struct AdminView_Previews: PreviewProvider {
    static var previews: some View {
        AdminView()
    }
}
