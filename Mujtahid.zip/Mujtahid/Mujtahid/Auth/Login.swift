//
//  Login.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct Login: View{
    @State var color = Color("Color")
    @State var email = ""
    @State var pass = ""
    @State var visible = false
    @Binding var show: Bool
    @State var alert = false
    @State var ShowresetView = false
    @State var error = ""
    var body: some View {
        
        ZStack{
            Color("bg").ignoresSafeArea()
            ZStack(alignment: .topTrailing){
                GeometryReader{ _ in
                    VStack{
                            Image("Logo")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 300, height: 300)
                ScrollView(.vertical, showsIndicators: false){
                        TextField("", text: self.$email)
                        .placeholder(when: email.isEmpty, placeholder: {
                        Text("الايميل")
                                .foregroundColor(self.color)
                                .opacity(0.6)
                    })
                        .multilineTextAlignment(TextAlignment.center)
                        .foregroundColor(self.color)
                        .autocapitalization(.none)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.email != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                        HStack(spacing: 15){
                            VStack{
                                if self.visible {
                                    TextField("", text: self.$pass)
                                        .placeholder(when: pass.isEmpty, placeholder: {
                                           Text("الرقم السري")
                                                .foregroundColor(self.color)
                                                .opacity(0.6)
                                        })
                                        .multilineTextAlignment(TextAlignment.center)
                                        .foregroundColor(self.color)
                                        .autocapitalization(.none)
                                } else {
                                    SecureField("" , text: self.$pass)
                                        .placeholder(when: pass.isEmpty, placeholder: {
                                           Text("الرقم السري")
                                                .foregroundColor(self.color)
                                                .opacity(0.6)
                                        })
                                        .multilineTextAlignment(TextAlignment.center)
                                        .foregroundColor(self.color)
                                        .autocapitalization(.none)
                                }
                            }
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.pass != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                        
                        HStack{
                            Button(action: {
                                self.visible.toggle()
                            }){
                                Image(systemName: self.visible ? "eye.slash.fill" : "eye.fill")
                                    .font(.headline)
                                    .foregroundColor(self.color)
                                    .opacity(0.6)
                            }
                            Spacer()
                            Button(action: {
                                ShowresetView = true
                            }) {
                                Text("نسيت الرقم السري")
                                    .fontWeight(.bold)
                                    .foregroundColor(color)
                            }
                        }
                        .padding(.top, 20)
                        Button(action: {
                            self.verify()
                        }) {
                            Text("تسجيل دخول")
                                .foregroundColor(Color("bg"))
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                    }
                    .padding(.horizontal ,25)
                   }
                }
                HStack{
                Button(action: {
                    self.show.toggle()
                }){
                    Text("تسجيل جديد")
                        .fontWeight(.bold)
                        .foregroundColor(color)
                }
                .padding()
               Spacer()
                }
            }.sheet(isPresented: $ShowresetView) {
                ForgotEmail(show: $ShowresetView)
            }
            if self.alert {
                ErrorView(alert: self.$alert, error:self.$error)
            }
        }
    }
    
    private func verify(){
        if self.email != "" && self.pass != "" {
            Auth.auth().signIn(withEmail: self.email, password: self.pass){ (res, err) in
                if err != nil {
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                print("Success")
                UserDefaults.standard.set(true, forKey: "status")
                NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
            }
            
        }else{
            self.error = "الرجاء اكمال البيانات"
            self.alert.toggle()
        }
    }
   
}

struct ForgotEmail: View {
  //  @StateObject var profileDate = ProfileViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State var color = Color("Color")
    @State var Name : String = ""
    @State var Email : String = ""
    @State var Password : String = ""
    @State var Rpassword : String = ""
    @State var ShohSignin = false
    @State var ShowRpassword = false
    @State var visible = false
    @Binding var show: Bool
    @State var alert = false
    @State var error = ""
    var body: some View {
        ZStack {
            Color("bg").ignoresSafeArea()
            VStack{
              
                
              
                VStack(spacing:1){
                 
                        
                ScrollView(.vertical, showsIndicators: false){
                    
                    HStack{
                        
                        Image("Logo")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 300, height: 300)
                    }
                    VStack(spacing:1){
                        
                       
                       
                        TextField("", text: self.$Email)
                        .placeholder(when: Email.isEmpty, placeholder: {
                        Text("الايميل")
                                .foregroundColor(self.color)
                                .opacity(0.6)
                    })
                        .multilineTextAlignment(TextAlignment.center)
                        .foregroundColor(self.color)
                        .autocapitalization(.none)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.Email != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                       
                    }.padding()
                    
                    
                    HStack{
                        
                        Button {
                            reset()
                            
                        } label: {
                            Text("ارسال الرقم السري")
                                .foregroundColor(Color("bg"))
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }.background(Color("Color"))
                            .cornerRadius(8)
                            .padding(.top, 25)
                      
                    }
                    Spacer()
                    if self.alert {
                        ErrorView(alert: self.$alert, error:self.$error)
                    }
                    
                   }
                  
                }
             
            }
        }
    }
    
    private func reset() {
        
        if self.Email != ""{
            Auth.auth().sendPasswordReset(withEmail: self.Email){ (err) in
                
                if err != nil {
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                
                self.error = "RESET"
                self.alert.toggle()
              
            }
        }else{
            self.error = "لا يوجد معلومات مسجلة لهذا الاميل"
            self.alert.toggle()
        }
    }
}


