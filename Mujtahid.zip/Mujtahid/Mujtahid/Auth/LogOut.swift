//
//  LogOut.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI

struct LogOut: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LogOut_Previews: PreviewProvider {
    static var previews: some View {
        LogOut()
    }
}
