//
//  CartModel.swift
//  Mujtahid
//
//  Created by abdullah FH on 03/08/1446 AH.
//

import SwiftUI
import Foundation
import Firebase

class CartModel :Identifiable {
    
  
    var ID : String?
    var UserID : String?
    var CartPDF : String?
    var CartName : String?
    var CartPrice : Double?
    var CartQuantitiy : Int?
    var CartDetails: String?
    var CartImage : String?
    var CartID : String?
    var TotaleCartPrice : String?
    
    init(ID : String , UserID : String , CartPDF : String , CartName : String, CartPrice : Double, CartQuantitiy : Int, CartDetails: String, CartImage : String ,CartID : String ,TotaleCartPrice : String) {
        self.ID = ID
        self.UserID = UserID
        self.CartPDF = CartPDF
        self.CartName = CartName
        self.CartPrice = CartPrice
        self.CartQuantitiy = CartQuantitiy
        self.CartDetails = CartDetails
        self.CartImage = CartImage
        self.CartID = CartID
        self.TotaleCartPrice = TotaleCartPrice
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.UserID = Dictionary["UserID"] as? String
        self.CartPDF = Dictionary["CartPDF"] as? String
        self.CartName = Dictionary["CartName"] as? String
        self.CartPrice = Dictionary["CartPrice"] as? Double
        self.CartQuantitiy = Dictionary["CartQuantitiy"] as? Int
        self.CartDetails = Dictionary["CartDetails"] as? String
        self.CartImage = Dictionary["CartImage"] as? String
        self.CartID = Dictionary["CartID"] as? String
        self.TotaleCartPrice = Dictionary["TotaleCartPrice"] as? String
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["UserID"] = self.UserID as AnyObject
        New["CartPDF"] = self.CartPDF as AnyObject
        New["CartName"] = self.CartName as AnyObject
        New["CartPrice"] = self.CartPrice as AnyObject
        New["CartQuantitiy"] = self.CartQuantitiy as AnyObject
        New["CartDetails"] = self.CartDetails as AnyObject
        New["CartImage"] = self.CartImage as AnyObject
        New["CartID"] = self.CartID as AnyObject
        New["TotaleCartPrice"] = self.TotaleCartPrice as AnyObject
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Carts").document(id).setData(MakeDictionary())
    }
    
    func Remove(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Carts").document(id).delete()
    }
    
    
    
    
}


class CartApi {
    
    
    static func GetCart(ID : String, completion : @escaping (_ Cart : CartModel)->()){
        
        Firestore.firestore().collection("Carts").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = CartModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllCarts(completion : @escaping (_ Cart : CartModel)->()){
        Firestore.firestore().collection("Carts").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = CartModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}
