//
//  OrderModel.swift
//  Mujtahid
//
//  Created by abdullah FH on 05/08/1446 AH.
//

import SwiftUI
import Foundation
import Firebase

class OrderModel :Identifiable {
    
  
    var ID : String?
    var UserID : String?
    var pdfFile: String?
    var UserName : String?
    var UserPhone : String?
    var OrderName : String?
    var OrderPrice : Double?
    var OrderQuantitiy : Int?
    var OrderDetails: String?
    var OrderImage : String?
    var OrderID : String?
    var TotaleOrderPrice : String?
    
    init(ID : String ,pdfFile: String , UserID : String ,UserName : String, UserPhone : String , OrderName : String, OrderPrice : Double, OrderQuantitiy : Int, OrderDetails: String, OrderImage : String ,OrderID : String ,TotaleOrderPrice : String) {
        self.ID = ID
        self.UserID = UserID
        self.pdfFile = pdfFile
        self.UserName = UserName
        self.UserPhone = UserPhone
        self.OrderName = OrderName
        self.OrderPrice = OrderPrice
        self.OrderQuantitiy = OrderQuantitiy
        self.OrderDetails = OrderDetails
        self.OrderImage = OrderImage
        self.OrderID = OrderID
        self.TotaleOrderPrice = TotaleOrderPrice
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.UserID = Dictionary["UserID"] as? String
        self.pdfFile = Dictionary["pdfFile"] as? String
        self.UserName = Dictionary["UserName"] as? String
        self.UserPhone = Dictionary["UserPhone"] as? String
        self.OrderName = Dictionary["OrderName"] as? String
        self.OrderPrice = Dictionary["OrderPrice"] as? Double
        self.OrderQuantitiy = Dictionary["OrderQuantitiy"] as? Int
        self.OrderDetails = Dictionary["OrderDetails"] as? String
        self.OrderImage = Dictionary["OrderImage"] as? String
        self.OrderID = Dictionary["OrderID"] as? String
        self.TotaleOrderPrice = Dictionary["TotaleOrderPrice"] as? String
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["UserID"] = self.UserID as AnyObject
        New["UserID"] = self.UserID as AnyObject
        New["UserName"] = self.UserName as AnyObject
        New["UserPhone"] = self.UserPhone as AnyObject
        New["OrderName"] = self.OrderName as AnyObject
        New["OrderPrice"] = self.OrderPrice as AnyObject
        New["OrderQuantitiy"] = self.OrderQuantitiy as AnyObject
        New["OrderDetails"] = self.OrderDetails as AnyObject
        New["OrderImage"] = self.OrderImage as AnyObject
        New["OrderID"] = self.OrderID as AnyObject
        New["TotaleOrderPrice"] = self.TotaleOrderPrice as AnyObject
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Orders").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class OrderApi {
    
    
    static func GetOrder(ID : String, completion : @escaping (_ Order : OrderModel)->()){
        
        Firestore.firestore().collection("Orders").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = OrderModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllOrders(completion : @escaping (_ Order : OrderModel)->()){
        Firestore.firestore().collection("Orders").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = OrderModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}
