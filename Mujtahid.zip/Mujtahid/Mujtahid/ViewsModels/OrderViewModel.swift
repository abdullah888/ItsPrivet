//
//  OrderViewModel.swift
//  Mujtahid
//
//  Created by abdullah FH on 05/08/1446 AH.
//

import SwiftUI
import Firebase


class OrderViewModel :ObservableObject{
    
    
    /*  // for add documentID
     let ref = firestore.collection(myCollection).document()
     // ref is a DocumentReference
     let id = ref.documentID
     */
   
    // UserObject
    @Published var Users: [UserModel] = []
    // PeoductObject
    @Published var Orders: [OrderModel] = []
    @Published var Orderdatas = [OrderModel]()

    let uiD = Auth.auth().currentUser?.uid
    let ref = Firestore.firestore()
    
    init(){
   // GetAllOrders()
     // fetchData()
        GetUser()
        UpdatUser_Order()
    }
   // its werk
    func GetUser(){
        UserApi.GetAllUsers { User in
        self.Users.append(User)
            
        }
    }
    func UpdatUser_Order(){
        UserApi.GetUser(ID: uiD!) { User in
            OrderApi.GetAllOrders { Order in
                if User.ID! != Order.UserID! {
                    self.Orders.append(Order)
                }
            }
     
        }
    }
   
    
    func GetAllOrders(){
        
        let db = Firestore.firestore()
       
            db.collection("Orders").addSnapshotListener { (snap, err) in
                
                if err != nil{
                    
                    print((err?.localizedDescription)!)
                    return
                }
                
                for i in snap!.documentChanges{
                    
                    let ID = i.document.documentID
                    let UserID = i.document.get("UserID") as! String
                    let pdfFile = i.document.get("pdfFile") as! String
                    let UserName = i.document.get("UserName") as! String
                    let UserPhone = i.document.get("UserPhone") as! String
                    let OrderName = i.document.get("OrderName") as! String
                    let OrderPrice = i.document.get("OrderPrice") as! Double
                    let OrderQuantitiy = i.document.get("OrderQuantitiy") as! Int
                    let OrderDetails = i.document.get("OrderDetails") as! String
                    let OrderImage = i.document.get("OrderImage") as! String
                    let OrderID = i.document.get("OrderID") as! String
                    let TotaleOrderPrice = i.document.get("TotaleOrderPrice") as! String
                    DispatchQueue.main.async {
                        self.Orders.append(OrderModel(ID: ID, pdfFile: pdfFile, UserID: UserID, UserName: UserName, UserPhone: UserPhone, OrderName: OrderName, OrderPrice: OrderPrice, OrderQuantitiy: OrderQuantitiy, OrderDetails: OrderDetails, OrderImage: OrderImage, OrderID: OrderID, TotaleOrderPrice: TotaleOrderPrice))
                }
           }
                
        }
    }
    
    //اضف الكود السريع وحط الاصافة من الهوم
    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Orders").getDocuments { (snap, err) in
            
            guard let OrderData = snap else{return}
            
            self.Orders = OrderData.documents.compactMap({ (doc) -> OrderModel? in
                
                let id = doc.documentID
                let UserID = doc.get("UserID") as! String
                let pdfFile = doc.get("pdfFile") as! String
                let UserName = doc.get("UserName") as! String
                let UserPhone = doc.get("UserPhone") as! String
                let OrderName = doc.get("OrderName") as! String
                let OrderPrice = doc.get("OrderPrice") as! Double
                let OrderQuantitiy = doc.get("OrderQuantitiy") as! Int
                let OrderDetails = doc.get("OrderDetails") as! String
                let OrderImage = doc.get("OrderImage") as! String
                let OrderID = doc.get("OrderID") as! String
                let TotaleOrderPrice = doc.get("TotaleOrderPrice") as! String
                return OrderModel(ID: id, pdfFile: pdfFile, UserID: UserID, UserName: UserName, UserPhone: UserPhone, OrderName: OrderName, OrderPrice: OrderPrice, OrderQuantitiy: OrderQuantitiy, OrderDetails: OrderDetails, OrderImage: OrderImage, OrderID: OrderID, TotaleOrderPrice: TotaleOrderPrice)
           
            })
            DispatchQueue.main.async {
                self.Orders = self.Orders
            }
        }
    }
    
   
    
    func deleteCollection(collection: String) {
      
        let db = Firestore.firestore()
           db.collection(collection).getDocuments() { (querySnapshot, err) in
               if let err = err {
                   print("Error getting documents: \(err)")
                   return
               }
               for document in querySnapshot!.documents {
                   print("Deleting \(document.documentID) => \(document.data())")
                   DispatchQueue.main.async {
                       document.reference.delete()
                   }
               }
           }
       }
    

    
    func calculateOrderTotalPrice()->String{
        
        var price : Float = 0
        
        Orders.forEach { (order) in
            price += Float(truncating: order.OrderQuantitiy! as NSNumber) * Float(truncating: order.OrderPrice! as NSNumber)
        }
        
        return getPrice(value: price)
    }
    
    func getPrice(value: Float)->String{
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        format.currencySymbol = "SR"
        return format.string(from: NSNumber(value: value)) ?? ""
    }
  
    

//    func addtoCart(){
//        let db = Firestore.firestore()
//        let id = Auth.auth().currentUser?.uid
//        Cartdatas.forEach { (Cart) in
//        db.collection("Carts")
//            .document(id!)
//            .setData(["CartName":product.ProductName!,
//                      "CartPrice":product.ProductPrice!,
//                      "CartQuantitiy":product.ProductQuantitiy!,
//                      "CartDetails":product.ProductDetails!,
//                      "CartImage":product.ProductImage!,
//                      "UserID":id!,
//                      "CartID":product.ID!,
//
//            ]) { (err) in
//
//                if err != nil{
//
//                    print((err?.localizedDescription)!)
//                    return
//                }
//
//                // it will dismiss the recently presented modal....
//
//            }
//
//        }
//    }
    
    
    
    
    // deleting Cart...
    
    func reset() {
    DispatchQueue.main.async {
        for i in 0..<self.Orders.count {
            self.Orders[i].OrderQuantitiy = 0
        }
        DispatchQueue.main.async {
            self.Orders.removeAll()
        }
    }
}
    
    func deletingOrder(id: String){
        let ref = Firestore.firestore()
        DispatchQueue.main.async {
            ref.collection("Orders").document(id).delete { (err) in
                if err != nil{
                    print(err!.localizedDescription)
                    return
                }
            }
        }
    }
    func Delete(){
        Orders.forEach { (i) in
            DispatchQueue.main.async {
                self.deletingOrder(id: i.ID!)
            }
        }
    }
  
      
}










