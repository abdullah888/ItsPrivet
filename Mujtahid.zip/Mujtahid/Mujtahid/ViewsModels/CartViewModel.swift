//
//  CartViewModel.swift
//  Mujtahid
//
//  Created by abdullah FH on 03/08/1446 AH.
//

import SwiftUI
import Firebase


class CartViewModel :ObservableObject{
    
    
    /*  // for add documentID
     let ref = firestore.collection(myCollection).document()
     // ref is a DocumentReference
     let id = ref.documentID
     */
   
    // PeoductObject
    @Published var Carts: [CartModel] = []
    @Published var Cartdatas = [CartModel]()

    let uiD = Auth.auth().currentUser?.uid
    let ref = Firestore.firestore()
    
    init(){
        Updete()
        
    }
  
 
    
    func  Updete() {
        Carts.forEach { (Cart) in
            DispatchQueue.main.async {
                if Cart.CartID! == self.uiD {
                    self.fetchData()
                }
            }
        }
    }
    
    
    func GetAllCart(){
        
        let db = Firestore.firestore()
       
            db.collection("Carts").addSnapshotListener { (snap, err) in
                
                if err != nil{
                    
                    print((err?.localizedDescription)!)
                    return
                }
                
                for i in snap!.documentChanges{
                    
                    let ID = i.document.documentID
                    let UserID = i.document.get("UserID") as! String
                    let CartPDF = i.document.get("CartPDF") as! String
                    let CartName = i.document.get("CartName") as! String
                    let CartPrice = i.document.get("CartPrice") as! Double
                    let CartQuantitiy = i.document.get("CartQuantitiy") as! Int
                    let CartDetails = i.document.get("CartDetails") as! String
                    let CartImage = i.document.get("CartImage") as! String
                    let CartID = i.document.get("CartID") as! String
                    let TotaleCartPrice = i.document.get("TotaleCartPrice") as! String
                    DispatchQueue.main.async {
                        self.Carts.append(CartModel(ID: ID,UserID: UserID, CartPDF: CartPDF ,CartName: CartName, CartPrice: CartPrice, CartQuantitiy: CartQuantitiy, CartDetails: CartDetails, CartImage: CartImage, CartID: CartID,TotaleCartPrice: TotaleCartPrice))
                }
           }
                
        }
    }
    
    //اضف الكود السريع وحط الاصافة من الهوم
    func GetCart(){
        ref.collection("Carts").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    CartApi.GetAllCarts { Cart in
                        CartApi.GetCart(ID: Cart.ID!) { Cart in
                            //her
                        }
                    }
         
                }
            }
        }
    }
    

    
    func fetchData(){
        
        let db = Firestore.firestore()
        
  
                db.collection("Carts").getDocuments { (snap, err) in
                    
                    guard let CartData = snap else{return}
                    
                    self.Carts = CartData.documents.compactMap({ (doc) -> CartModel? in
                     
                        let id = doc.documentID
                        let UserID = doc.get("UserID") as! String
                        let CartPDF = doc.get("CartPDF") as! String
                        let CartName = doc.get("CartName") as! String
                        let CartPrice = doc.get("CartPrice") as! Double
                        let CartQuantitiy = doc.get("CartQuantitiy") as! Int
                        let CartDetails = doc.get("CartDetails") as! String
                        let CartImage = doc.get("CartImage") as! String
                        let CartID = doc.get("CartID") as! String
                        let TotaleCartPrice = doc.get("TotaleCartPrice") as! String
                        return CartModel(ID: id,UserID: UserID, CartPDF: CartPDF, CartName: CartName, CartPrice: CartPrice, CartQuantitiy: CartQuantitiy, CartDetails: CartDetails, CartImage: CartImage, CartID: CartID,TotaleCartPrice: TotaleCartPrice)
               
                    })
                    DispatchQueue.main.async {
                        self.Carts = self.Carts
                    }
                }
            }
      
   
    
    func deleteCollection(collection: String ) {
      
        let db = Firestore.firestore()
           db.collection(collection).getDocuments() { (querySnapshot, err) in
               if let err = err {
                   print("Error getting documents: \(err)")
                   return
               }
               for document in querySnapshot!.documents {
                   print("Deleting \(document.documentID) => \(document.data())")
                   DispatchQueue.main.async {
                       document.reference.delete()
                   }
               }
           }
       }
    

    
    func calculateCartTotalPrice()->String{
        
        var price : Float = 0
            Carts.forEach { (Cart) in
                if Cart.UserID == uiD {
                    price += Float(truncating: Cart.CartQuantitiy! as NSNumber) * Float(truncating: Cart.CartPrice! as NSNumber)
                }
            }
            return getPrice(value: price)
        }
    
    func getPrice(value: Float)->String{
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        format.currencySymbol = "SR"
        return format.string(from: NSNumber(value: value)) ?? ""
    }
  
  
    // deleting Cart...
    
    func reset() {
    DispatchQueue.main.async {
        for i in 0..<self.Carts.count {
            self.Carts[i].CartQuantitiy = 0
        }
        
        self.Carts.forEach { (Cart) in
            DispatchQueue.main.async {
                if Cart.UserID == self.uiD {
                    self.Carts.removeAll()
                }
            }
        }
    }
}
    
    func deletingCart(id: String){
        let ref = Firestore.firestore()
    
            DispatchQueue.main.async {
                ref.collection("Carts").document().delete { (err) in
                    if err != nil{
                        print(err!.localizedDescription)
                        return
                    }
                }
            }
    }
    func Delete(){
        Carts.forEach { (i) in
            DispatchQueue.main.async {
                self.deletingCart(id: i.UserID!)
            }
        }
    }
  
      
}





// code


//
//func UpData(){
//
//
//
//    ref.collection("Carts").addSnapshotListener { (snap, err) in
//
//        if err != nil{
//
//            print((err?.localizedDescription)!)
//            return
//        }
//
//        for i in snap!.documentChanges{
//
//            if i.type == .added{
//
//                let ID = i.document.documentID
//                let UserID = i.document.get("UserID") as! String
//                let CartName = i.document.get("CartName") as! String
//                let CartPrice = i.document.get("CartPrice") as! Double
//                let CartQuantitiy = i.document.get("CartQuantitiy") as! Int
//                let CartDetails = i.document.get("CartDetails") as! String
//                let CartImage = i.document.get("CartImage") as! String
//                let CartID = i.document.get("CartID") as! String
//                let TotaleCartPrice = i.document.get("TotaleCartPrice") as! String
//                DispatchQueue.main.async {
//                    self.Carts.append(CartModel(ID: ID,UserID: UserID ,CartName: CartName, CartPrice: CartPrice, CartQuantitiy: CartQuantitiy, CartDetails: CartDetails, CartImage: CartImage, CartID: CartID,TotaleCartPrice: TotaleCartPrice))
//                  }
//            }
//
//            if i.type == .modified{
//
//                let id = i.document.documentID
//                let quantity = i.document.get("Order_quantity") as! NSNumber
//
//                for j in 0..<self.datas.count{
//
//                    if self.datas[j].id == id{
//
//                        self.datas[j].quantity = quantity
//                    }
//                }
//            }
//        }
//    }
//}
