//
//  Setting.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct Setting: View {
    var animation: Namespace.ID
    @State var showAdminView: Bool = false
    @StateObject var Userdata = ProfileViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State var color = Color("Color")
    @State var isDarkModeEnabled: Bool = true
    @State var downloadViaWifiEnabled: Bool = false
    
    var body: some View {
        NavigationView {
            VStack{
                Form {
                    Group {
                        HStack{
                            Spacer()
                            VStack {
                                WebImage(url: URL(string: Userdata.userInfo.Image!))
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width:100, height: 100, alignment: .center)
                                    .aspectRatio(contentMode: .fit)
                                    .cornerRadius(50)
                                Text(Userdata.userInfo.Name!)
                                    .font(.title)
                                    .foregroundColor(color)
                                Text((Auth.auth().currentUser?.email)!)
                                    .font(.subheadline)
                                    .foregroundColor(color)
                                Spacer()
                                Button(action: {
                                    print("Edit Profile tapped")
                                }) {
                                    Text("Edit Profile")
                                        .frame(minWidth: 0, maxWidth: .infinity)
                                        .font(.system(size: 18))
                                        .padding()
                                        .foregroundColor(color)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 25)
                                                .stroke(Color.white, lineWidth: 2)
                                        )
                                }
                                .background(Color("g1"))
                                .cornerRadius(25)
                            }
                            Spacer()
                        }
                    }
                    
                    Section(header: Text("CONTENT"), content: {
                        HStack{
                            Image(systemName: "heart.fill")
              
                       
                        }

                        HStack{
                            
                    
                            Image(systemName: "figure.walk.arrival")
                           
                        }

                    }).foregroundColor(color)
                    .background(Color("g1"))

                    Section(header: Text("PREFRENCES"), content: {
                        HStack{
                            Image(systemName: "heart.fill")
                            Text("Language")
                        }
                        HStack{
                            Image(systemName: "heart.fill")
                            Toggle(isOn: $isDarkModeEnabled) {
                                Text("Dark Mode")
                            }.tint(color)
                        }
                        HStack{
                            Image(systemName: "heart.fill")
                            Toggle(isOn: $downloadViaWifiEnabled) {
                                Text("Only Download via Wi-Fi")
                            }.tint(color)
                        }
                        HStack{
                            Image(systemName: "heart.fill")
                            Text("Play in Background")
                        }

                    }).foregroundColor(color)
                }
            }
            .toolbar {
                HStack{
                    Button {
                       showAdminView = true
                    } label: {
                        Image(systemName: "keyboard.chevron.compact.left")
                            .font(.title)
                            .foregroundColor(color)
                        
                    }
                   
                    Button {
                        try! Auth.auth().signOut()
                        UserDefaults.standard.set(false, forKey: "status")
                        NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
                    } label: {
                        Image(systemName: "power")
                            .font(.title)
                            .foregroundColor(.red)
                        
                    } .padding()
                }
                       }
                   
        }.sheet(isPresented: $showAdminView) {
            AdminView()
        }
       
        
    }
}

