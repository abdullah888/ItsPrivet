//
//  CellView.swift
//  Mujtahid
//
//  Created by abdullah FH on 01/08/1446 AH.
//

import SwiftUI

struct CellView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CellView_Previews: PreviewProvider {
    static var previews: some View {
        CellView()
    }
}
