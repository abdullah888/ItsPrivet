//
//  Library.swift
//  Mujtahid
//
//  Created by abdullah FH on 01/08/1446 AH.
//

import SwiftUI
import Firebase
import FirebaseStorage
import SDWebImageSwiftUI

struct Library : View {
    @State private var presentImporter = false
    
    var body: some View {
        Button("Open") {
            presentImporter = true
        }.fileImporter(isPresented: $presentImporter, allowedContentTypes: [.pdf]) { result in
            switch result {
            case .success(let url):
                let storage = Storage.storage()

                // Create a storage reference from our storage service
                let storageRef = storage.reference()

                // File located on disk
                let localFile = URL(string: url.absoluteString)!

                    // Create a reference to the file you want to upload
                    let riversRef = storageRef.child("pdfFiles")

                    // Upload the file to the path "docs/rivers.pdf"
                    let uploadTask = riversRef.putFile(from: localFile, metadata: nil) { metadata, error in
                      guard let metadata = metadata else {
                        // Uh-oh, an error occurred!
                        return
                      }
                      // Metadata contains file metadata such as size, content-type.
                      let size = metadata.size
                      // You can also access to download URL after upload.
                      storageRef.downloadURL { (url, error) in
                          guard url != nil else {
                          // Uh-oh, an error occurred!
                          return
                        }
                      }
                    }
                print(url)
                //use `url.startAccessingSecurityScopedResource()` if you are going to read the data
            case .failure(let error):
                print(error)
            }
        }
    }
    
    
}

struct Library_Previews: PreviewProvider {
    static var previews: some View {
        Library()
    }
}


