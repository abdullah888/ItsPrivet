//
//  AddProduct.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
struct AddProduct: View {
    @State var color = Color("Color")
    @StateObject var Producttdata = ProductViewModel()
    @StateObject var Userdata = ProfileViewModel()
    @State var img_Data = Data.init(count: 0)
    @State var ProductName = ""
    @State var ProductPrice = ""
    @State var ProductQuantitiy = ""
    @State var ProductDetails = ""
    @Environment(\.presentationMode) var presentationMode
    @State var picker = false
    @State private var showingAlert = false
    var body: some View {
        NavigationStack {
            HStack{
                
                Text("صفحة الاضافة")
                    .font(.title)
                    .foregroundColor(color)
                    .padding()
                Spacer()
                Button {
                    UploadProduct()

                } label: {
                    Text("ارسال")
                        .font(.title)
                        .frame(width: 100,height: 55)
                        .background(color)
                        .cornerRadius(10)
                        .foregroundColor(Color("bg"))
                        .padding(.vertical,30)
                }
               
            }
            ZStack{
                Color.black.edgesIgnoringSafeArea(.all)
                ScrollView(.vertical, showsIndicators: false){
                    VStack{
                        VStack{
                            if img_Data.count != 0 {
                                Image(uiImage: UIImage(data: img_Data)!)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: UIScreen.main.bounds.width - 10, height: UIScreen.main.bounds.height / 3)
                                    .clipShape(RoundedRectangle(cornerRadius:8))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .strokeBorder(.white, lineWidth: 0.1)
                                    )
                                
                            } else {
                                Image(systemName: "photo.on.rectangle")
                                    .font(.system(size: 100))
                                    .foregroundColor(self.color)
                                    .frame(width: UIScreen.main.bounds.width - 10, height: UIScreen.main.bounds.height / 3)
                                    .clipShape(RoundedRectangle(cornerRadius:8))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .strokeBorder(.white, lineWidth: 0.1)
                                    )
                            }
                        }.onTapGesture(perform: {
                            self.picker = true
                        })
                        
                        
                        
                        VStack(spacing: 15){
                            TextField("", text: self.$ProductName)
                                .placeholder(when: ProductName.isEmpty, placeholder: {
                                    Text("الاسم")
                                        .foregroundColor(self.color)
                                        .opacity(0.6)
                                })
                                .multilineTextAlignment(TextAlignment.center)
                                .foregroundColor(self.color)
                                .autocapitalization(.none)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 4).stroke(self.ProductName != "" ? Color("Color") : self.color, lineWidth: 2))
                                .padding(.top, 25)
                            
                            TextField("", text: self.$ProductPrice)
                                .placeholder(when: ProductPrice.isEmpty, placeholder: {
                                    Text("السعر")
                                        .foregroundColor(self.color)
                                        .opacity(0.6)
                                })
                                .multilineTextAlignment(TextAlignment.center)
                                .foregroundColor(self.color)
                                .autocapitalization(.none)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 4).stroke(self.ProductPrice != "" ? Color("Color") : self.color, lineWidth: 2))
                                .padding(.top, 25)
                            
                            TextField("", text: self.$ProductQuantitiy)
                                .placeholder(when: ProductQuantitiy.isEmpty, placeholder: {
                                    Text("العدد")
                                        .foregroundColor(self.color)
                                        .opacity(0.6)
                                })
                                .multilineTextAlignment(TextAlignment.center)
                                .foregroundColor(self.color)
                                .autocapitalization(.none)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 4).stroke(self.ProductQuantitiy != "" ? Color("Color") : self.color, lineWidth: 2))
                                .padding(.top, 25)
                            
                            TextEditor(text: $ProductDetails)
                                .placeholder(when: ProductDetails.isEmpty, placeholder: {
                                    Text("معلومات")
                                        .foregroundColor(self.color)
                                        .opacity(0.6)
                                })
                                .multilineTextAlignment(TextAlignment.trailing)
                                .scrollContentBackground(.hidden)
                                .foregroundColor(self.color)
                                .autocapitalization(.none)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 4).stroke(self.ProductDetails != "" ? Color("Color") : self.color, lineWidth: 2))
                                .padding(.top, 25)
                                     
                           }
                        }
                    }
                }
        }
        .sheet(isPresented: $picker) {
            ImagePicker(picker: $picker, img_Data: $img_Data)
        }
        .alert(isPresented:$showingAlert) {
            Alert(
                title: Text("يلزم التسجيل"),
                message: Text("من اجل النشر"),
                primaryButton: .destructive(Text("تسجيل")) {
                 //  showaduser = true
                },
                secondaryButton: .cancel()
            )
        }
    }
    
  
    func UploadProduct(){
        let db = Firestore.firestore()
        Auth.auth().addStateDidChangeListener { auth, user in
        UploadImage(imageData: self.img_Data, path: "Products_Image") { url in
            db.collection("Products")
                .document()
                .setData(["ID": UUID().uuidString,
                          "ProductName":ProductName,
                          "ProductPrice":Double(self.ProductPrice) ?? 0.0,
                          "ProductQuantitiy":Int(ProductQuantitiy)!,
                          "ProductDetails":ProductDetails,
                          "ProductImage":url]) { (err) in
                    if err != nil{
                        print((err?.localizedDescription)!)
                        return
                           }
                       }
                }
        }
        presentationMode.wrappedValue.dismiss()
    }
}




