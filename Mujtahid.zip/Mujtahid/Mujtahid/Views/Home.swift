//
//  Home.swift
//  Mujtahid
//
//  Created by abdullah FH on 24/07/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct Home: View {
 //   @StateObject var ProductData = ProductViewModel()
    var animation: Namespace.ID
    @State var ShowSearch = false
    @State var Showbasket = false
    @State var color = Color("Color")
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(color)
                
                Spacer()
            }
    }
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

